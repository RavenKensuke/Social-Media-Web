<?php 
$conn = mysqli_connect("localhost", "root", "", "social_media_project");
